Fnaf  World Installer. 
Works only with Steam installed. (with account!)
This file was tested on Windows 11 
Its fully safe:
Works like steam's open system (steam://rungameid/...) but with install. (steam://install/...)

